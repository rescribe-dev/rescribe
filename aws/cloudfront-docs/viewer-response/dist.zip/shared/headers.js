"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseHeadersFile = void 0;
const fs_1 = __importDefault(require("fs"));
const TOKEN_COMMENT = '#';
const TOKEN_PATH = '/';
const headersFile = '../_headers';
exports.parseHeadersFile = () => {
    const rules = {};
    if (!fs_1.default.existsSync(headersFile))
        return rules;
    if (fs_1.default.statSync(headersFile).isDirectory()) {
        console.warn('expected _headers file but found a directory at:', headersFile);
        return rules;
    }
    const lines = fs_1.default.readFileSync(headersFile, { encoding: 'utf8' }).split('\n');
    if (lines.length < 1)
        return rules;
    let path = undefined;
    for (let i = 0; i <= lines.length; i++) {
        if (!lines[i])
            continue;
        const line = lines[i].trim();
        if (line.startsWith(TOKEN_COMMENT) || line.length < 1)
            continue;
        if (line.startsWith(TOKEN_PATH)) {
            if (line.includes('*') && line.indexOf('*') !== line.length - 1) {
                throw new Error(`invalid rule (A path rule cannot contain anything after * token) at line: ${i}\n${lines[i]}\n`);
            }
            path = line;
            continue;
        }
        if (!path)
            throw new Error('path should come before headers');
        if (line.includes(':')) {
            const sepIndex = line.indexOf(':');
            if (sepIndex < 1)
                throw new Error(`invalid header at line: ${i}\n${lines[i]}\n`);
            const key = line.substr(0, sepIndex).trim();
            const value = line.substr(sepIndex + 1).trim();
            if (path in rules) {
                if (key in rules[path]) {
                    rules[path][key].push(value);
                }
                else {
                    rules[path][key] = [value];
                }
            }
            else {
                rules[path] = { [key]: [value] };
            }
        }
    }
    return rules;
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGVhZGVycy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9zaGFyZWQvaGVhZGVycy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7QUFFQSw0Q0FBb0I7QUFFcEIsTUFBTSxhQUFhLEdBQUcsR0FBRyxDQUFDO0FBQzFCLE1BQU0sVUFBVSxHQUFHLEdBQUcsQ0FBQztBQVV2QixNQUFNLFdBQVcsR0FBRyxhQUFhLENBQUM7QUFFckIsUUFBQSxnQkFBZ0IsR0FBRyxHQUFTLEVBQUU7SUFDekMsTUFBTSxLQUFLLEdBQVMsRUFBRSxDQUFDO0lBQ3ZCLElBQUksQ0FBQyxZQUFFLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQztRQUFFLE9BQU8sS0FBSyxDQUFDO0lBQzlDLElBQUksWUFBRSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsQ0FBQyxXQUFXLEVBQUUsRUFBRTtRQUMxQyxPQUFPLENBQUMsSUFBSSxDQUFDLGtEQUFrRCxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBQzlFLE9BQU8sS0FBSyxDQUFDO0tBQ2Q7SUFFRCxNQUFNLEtBQUssR0FBRyxZQUFFLENBQUMsWUFBWSxDQUFDLFdBQVcsRUFBRSxFQUFFLFFBQVEsRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUM3RSxJQUFJLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQztRQUFFLE9BQU8sS0FBSyxDQUFDO0lBRW5DLElBQUksSUFBSSxHQUF1QixTQUFTLENBQUM7SUFDekMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7UUFDdEMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7WUFBRSxTQUFTO1FBRXhCLE1BQU0sSUFBSSxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUU3QixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDO1lBQUUsU0FBUztRQUNoRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLEVBQUU7WUFDL0IsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7Z0JBQy9ELE1BQU0sSUFBSSxLQUFLLENBQUMsNkVBQTZFLENBQUMsS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ2xIO1lBQ0QsSUFBSSxHQUFHLElBQUksQ0FBQztZQUNaLFNBQVM7U0FDVjtRQUVELElBQUksQ0FBQyxJQUFJO1lBQUUsTUFBTSxJQUFJLEtBQUssQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDO1FBRTlELElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUN0QixNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ25DLElBQUksUUFBUSxHQUFHLENBQUM7Z0JBQUUsTUFBTSxJQUFJLEtBQUssQ0FBQywyQkFBMkIsQ0FBQyxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7WUFFakYsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDNUMsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7WUFFL0MsSUFBSSxJQUFJLElBQUksS0FBSyxFQUFFO2dCQUNqQixJQUFJLEdBQUcsSUFBSSxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUU7b0JBQ3RCLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7aUJBQzlCO3FCQUFNO29CQUNMLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO2lCQUM1QjthQUNGO2lCQUFNO2dCQUNMLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2FBQ2xDO1NBQ0Y7S0FDRjtJQUNELE9BQU8sS0FBSyxDQUFDO0FBQ2YsQ0FBQyxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiLy8gZnJvbSBodHRwczovL3Jhdy5naXRodWJ1c2VyY29udGVudC5jb20vbmV0bGlmeS9jbGkvbWFzdGVyL3NyYy91dGlscy9oZWFkZXJzLmpzXG5cbmltcG9ydCBmcyBmcm9tICdmcyc7XG5cbmNvbnN0IFRPS0VOX0NPTU1FTlQgPSAnIyc7XG5jb25zdCBUT0tFTl9QQVRIID0gJy8nO1xuXG5pbnRlcmZhY2UgaGVhZGVycyB7XG4gIFtoZWFkZXI6IHN0cmluZ106IHN0cmluZ1tdO1xufVxuXG5pbnRlcmZhY2UgZGF0YSB7XG4gIFtwYXRoOiBzdHJpbmddOiBoZWFkZXJzO1xufVxuXG5jb25zdCBoZWFkZXJzRmlsZSA9ICcuLi9faGVhZGVycyc7XG5cbmV4cG9ydCBjb25zdCBwYXJzZUhlYWRlcnNGaWxlID0gKCk6IGRhdGEgPT4ge1xuICBjb25zdCBydWxlczogZGF0YSA9IHt9O1xuICBpZiAoIWZzLmV4aXN0c1N5bmMoaGVhZGVyc0ZpbGUpKSByZXR1cm4gcnVsZXM7XG4gIGlmIChmcy5zdGF0U3luYyhoZWFkZXJzRmlsZSkuaXNEaXJlY3RvcnkoKSkge1xuICAgIGNvbnNvbGUud2FybignZXhwZWN0ZWQgX2hlYWRlcnMgZmlsZSBidXQgZm91bmQgYSBkaXJlY3RvcnkgYXQ6JywgaGVhZGVyc0ZpbGUpO1xuICAgIHJldHVybiBydWxlcztcbiAgfVxuXG4gIGNvbnN0IGxpbmVzID0gZnMucmVhZEZpbGVTeW5jKGhlYWRlcnNGaWxlLCB7IGVuY29kaW5nOiAndXRmOCcgfSkuc3BsaXQoJ1xcbicpO1xuICBpZiAobGluZXMubGVuZ3RoIDwgMSkgcmV0dXJuIHJ1bGVzO1xuXG4gIGxldCBwYXRoOiBzdHJpbmcgfCB1bmRlZmluZWQgPSB1bmRlZmluZWQ7XG4gIGZvciAobGV0IGkgPSAwOyBpIDw9IGxpbmVzLmxlbmd0aDsgaSsrKSB7XG4gICAgaWYgKCFsaW5lc1tpXSkgY29udGludWU7XG5cbiAgICBjb25zdCBsaW5lID0gbGluZXNbaV0udHJpbSgpO1xuXG4gICAgaWYgKGxpbmUuc3RhcnRzV2l0aChUT0tFTl9DT01NRU5UKSB8fCBsaW5lLmxlbmd0aCA8IDEpIGNvbnRpbnVlO1xuICAgIGlmIChsaW5lLnN0YXJ0c1dpdGgoVE9LRU5fUEFUSCkpIHtcbiAgICAgIGlmIChsaW5lLmluY2x1ZGVzKCcqJykgJiYgbGluZS5pbmRleE9mKCcqJykgIT09IGxpbmUubGVuZ3RoIC0gMSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYGludmFsaWQgcnVsZSAoQSBwYXRoIHJ1bGUgY2Fubm90IGNvbnRhaW4gYW55dGhpbmcgYWZ0ZXIgKiB0b2tlbikgYXQgbGluZTogJHtpfVxcbiR7bGluZXNbaV19XFxuYCk7XG4gICAgICB9XG4gICAgICBwYXRoID0gbGluZTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIGlmICghcGF0aCkgdGhyb3cgbmV3IEVycm9yKCdwYXRoIHNob3VsZCBjb21lIGJlZm9yZSBoZWFkZXJzJyk7XG5cbiAgICBpZiAobGluZS5pbmNsdWRlcygnOicpKSB7XG4gICAgICBjb25zdCBzZXBJbmRleCA9IGxpbmUuaW5kZXhPZignOicpO1xuICAgICAgaWYgKHNlcEluZGV4IDwgMSkgdGhyb3cgbmV3IEVycm9yKGBpbnZhbGlkIGhlYWRlciBhdCBsaW5lOiAke2l9XFxuJHtsaW5lc1tpXX1cXG5gKTtcblxuICAgICAgY29uc3Qga2V5ID0gbGluZS5zdWJzdHIoMCwgc2VwSW5kZXgpLnRyaW0oKTtcbiAgICAgIGNvbnN0IHZhbHVlID0gbGluZS5zdWJzdHIoc2VwSW5kZXggKyAxKS50cmltKCk7XG5cbiAgICAgIGlmIChwYXRoIGluIHJ1bGVzKSB7XG4gICAgICAgIGlmIChrZXkgaW4gcnVsZXNbcGF0aF0pIHtcbiAgICAgICAgICBydWxlc1twYXRoXVtrZXldLnB1c2godmFsdWUpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJ1bGVzW3BhdGhdW2tleV0gPSBbdmFsdWVdO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBydWxlc1twYXRoXSA9IHsgW2tleV06IFt2YWx1ZV0gfTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIHJ1bGVzO1xufTtcbiJdfQ==