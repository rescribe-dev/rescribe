"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.absolutePath = void 0;
exports.absolutePath = /^([a-zA-Z0-9_\\/.\-()])+(\.[a-zA-Z0-9]+)$/;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVnZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvc2hhcmVkL3JlZ2V4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFhLFFBQUEsWUFBWSxHQUFHLDJDQUEyQyxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNvbnN0IGFic29sdXRlUGF0aCA9IC9eKFthLXpBLVowLTlfXFxcXC8uXFwtKCldKSsoXFwuW2EtekEtWjAtOV0rKSQvO1xuIl19