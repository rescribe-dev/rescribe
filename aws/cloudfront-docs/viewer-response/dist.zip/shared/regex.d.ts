export declare const absolutePath: RegExp;
