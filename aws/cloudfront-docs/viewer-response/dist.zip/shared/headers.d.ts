interface headers {
    [header: string]: string[];
}
interface data {
    [path: string]: headers;
}
export declare const parseHeadersFile: () => data;
export {};
