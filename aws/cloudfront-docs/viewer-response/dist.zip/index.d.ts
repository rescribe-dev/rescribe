import { CloudFrontResponseHandler } from 'aws-lambda';
export declare const handler: CloudFrontResponseHandler;
